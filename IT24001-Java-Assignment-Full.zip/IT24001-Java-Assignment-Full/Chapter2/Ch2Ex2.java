import java.util.Scanner;
public class Ch2Ex2 {
  public static void main(String[] args){
    Scanner input = new Scanner(System.in);
    System.out.print("Enter radius and length of cylinder: ");
    double r=input.nextDouble(), l=input.nextDouble();
    double area=Math.PI*r*r;
    double volume=area*l;
    System.out.println("Area: " + area + " Volume: " + volume);
  }
}