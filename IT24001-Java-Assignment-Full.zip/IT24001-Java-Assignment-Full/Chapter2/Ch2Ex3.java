import java.util.Scanner;
public class Ch2Ex3 {
  public static void main(String[] args){
    Scanner input=new Scanner(System.in);
    System.out.print("Enter value in feet: ");
    double feet=input.nextDouble();
    double meters=feet*0.305;
    System.out.println(feet + " feet is " + meters + " meters");
  }
}